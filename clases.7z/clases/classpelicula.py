# -*- coding: utf-8 -*-
class Pelicula:
    
    def __init__(self, titulo,  director, año_estreno, genero, duracion):
        self.titulo = titulo
        self.director = director
        self.año_estreno = año_estreno
        self.genero = genero
        self.duracion = duracion
        
    def descripcion(self):
        return F"'{self.titulo}' fue dirigido por {self.director} estrenado en {self.año_estreno}. Genero: {self.genero}. Duracion: {self.duracion}. min"
    
    def es_clasico(self):
        return self.año_estreno<1960
    
pelicula = Pelicula("Volver al futuro", "Robert Zemeckis", 1985, "Ciencia Ficcion", 116)
print(pelicula.descripcion())

if pelicula.es_clasico():
    print("Esta Pelicula es un clasico")
else:
    print("Esta pelicula no es un clasico")

