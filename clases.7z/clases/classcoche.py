# -*- coding: utf-8 -*-
class Coche:
    
    def __init__(self, marca, modelo, año, color):
        self.marca = marca
        self.modelo = modelo
        self.año = año
        self.color = color
        self.encendido = False
        
    def encender (self):
        if not self.encendido:
            self.encendido = True
            return f" El {self.marca} {self.modelo} esta encendido."
        else:
            return "El coche ya esta encendido."
        
    def apagar(self):
        if self.encendido:
            self.encendido = False
            return  f" El {self.marca} {self.modelo} ha sido apagado."
        else:
            return "El coche ya esta apagado"
    def descripcion(self):
        return f"{self.marca} {self.modelo} año {self.año}. Color| {self.color}."
    
coche1 = Coche("Toyota", "Corolla", 2020, "Rojo")

print(coche1.descripcion())
print(coche1.encender())
print(coche1.apagar())