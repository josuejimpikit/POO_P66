# -*- coding: utf-8 -*-
class Pelicula:
    
    def __init__(self, titulo,  director, año_estreno, genero, duracion):
        self.titulo = titulo
        self.director = director
        self.año_estreno = año_estreno
        self.genero = genero
        self.duracion = duracion
        
    def descripcion(self):
        return F"'{self.titulo}' fue dirigido por {self.director} estrenado en {self.año_estreno}. Genero: {self.genero}. Duracion: {self.duracion}. min"
    
    def es_clasico(self):
        return self.año_estreno<1960
    
pelicula = Pelicula("Volver al futuro", "Robert Zemeckis", 1985, "Ciencia Ficcion", 116)
print(pelicula.descripcion())

if pelicula.es_clasico():
    print("Esta Pelicula es un clasico")
else:
    print("Esta pelicula no es un clasico")


class Cine:
    
    def __init__(self, nombre):
        self.nombre = nombre
        self.cartelera = []
    
    def agregar_peli(self, pelicula):
        self.cartelera.append(pelicula) #agrega un pelicula a lista cartelera
    
    def mostrar_cartelera(self):
        print(f"Cartelera del cine {self.nombre}:")
        
        for peli in self.cartelera:
            print(f"- {peli.titulo} ({peli.año_estreno})")
            
    def buscar_pelicula(self, titulo):
        for peli in self.cartelera:
            if peli.titulo.lower()==titulo.lower():
                return peli.descripcion()
                return "Pelicula no encontrada en la cartelera."
            
cine1= Cine("Cinemark Quito")
peli1= Pelicula("Titanic", "James Cameron", 1997, "Drama", 195)
peli2= Pelicula("Avatar", "James cameron", 2009, "Ciencia Ficcion", 162)

cine1.agregar_peli(peli1)
cine1.agregar_peli(peli2)

cine1.mostrar_cartelera()

print(cine1.buscar_pelicula("Titanic"))        