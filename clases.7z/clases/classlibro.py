# -*- coding: utf-8 -*-
class Libro:
    
    def __init__(self, titulo, autor, año_publicacion, genero):
        self.titulo = titulo
        self.autor = autor
        self.año_publicacion = año_publicacion
        self.genero = genero
        
    def descripcion(self):
        return F"'{self.titulo}' fue escrito por {self.autor} en {self.año_publicacion}. Genero: {self.genero}."
    
    def es_clasico(self):
        return self.año_publicacion<1980
    
libro = Libro("Cien años de soledad", "Gabriel Garcia Marquez", 1967, "Realismo magico")
print(libro.descripcion())

if libro.es_clasico():
    print("Este libro es un clasico")
else:
    print("Este libro no es un clasico")
    